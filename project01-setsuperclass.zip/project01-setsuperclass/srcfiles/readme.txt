srcfiles$ mkdir ../classfiles
srcfiles$ javac -d ../classfiles/ *.java
srcfiles$ ls -la ../classfiles/target/
total 16
drwxr-xr-x  4 mksong  staff  128 Jan 10 12:21 .
drwxr-xr-x  3 mksong  staff   96 Jan 10 12:21 ..
-rw-r--r--  1 mksong  staff  488 Jan 10 12:21 Point.class
-rw-r--r--  1 mksong  staff  254 Jan 10 12:21 Rectangle.class

